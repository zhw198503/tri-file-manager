import 'package:flutter/material.dart';
import '../services/file_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_getAppBarTitle()),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: IndexedStack(
        index: _currentIndex,
        children: const [
          FileListScreen(type: FileSystemType.android),
          FileListScreen(type: FileSystemType.termux),
          FileListScreen(type: FileSystemType.ubuntu),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) => setState(() => _currentIndex = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.android), label: '安卓'),
          NavigationDestination(icon: Icon(Icons.terminal), label: 'Termux'),
          NavigationDestination(icon: Icon(Icons.laptop), label: 'Ubuntu'),
        ],
      ),
    );
  }

  String _getAppBarTitle() {
    switch (_currentIndex) {
      case 0: return '安卓文件';
      case 1: return 'Termux 文件';
      case 2: return 'Ubuntu 文件';
      default: return '文件管理';
    }
  }
}

class FileListScreen extends StatefulWidget {
  final FileSystemType type;
  const FileListScreen({super.key, required this.type});

  @override
  State<FileListScreen> createState() => _FileListScreenState();
}

class _FileListScreenState extends State<FileListScreen> {
  List<FileEntry> _files = [];
  bool _loading = false;
  String _currentPath = '/';

  @override
  void initState() {
    super.initState();
    _loadFiles(_currentPath);
  }

  Future<void> _loadFiles(String path) async {
    setState(() => _loading = true);
    try {
      final files = await FileService.listFiles(widget.type, path);
      setState(() {
        _files = files;
        _currentPath = path;
      });
    } catch (e) {
      print("加载文件失败: $e");
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    return ListView.builder(
      itemCount: _files.length,
      itemBuilder: (context, index) {
        final file = _files[index];
        return ListTile(
          leading: Icon(file.isDir ? Icons.folder : Icons.insert_drive_file),
          title: Text(file.name),
          subtitle: Text(file.path),
          onTap: () {
            if (file.isDir) {
              _loadFiles(file.path);
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('点击了文件: ${file.name}')),
              );
            }
          },
        );
      },
    );
  }
}
