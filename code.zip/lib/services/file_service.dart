import 'dart:io';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'shizuku_service.dart';

enum FileSystemType {
  android,
  termux,
  ubuntu
}

class FileEntry {
  final String name;
  final bool isDir;
  final String path;
  final int? size;

  FileEntry({required this.name, required this.isDir, required this.path, this.size});

  factory FileEntry.fromJson(Map<String, dynamic> json) {
    return FileEntry(
      name: json['name'] ?? '',
      isDir: json['isDir'] ?? false,
      path: json['path'] ?? '',
      size: json['size'],
    );
  }
}

class FileService {
  // Termux 和 Ubuntu 的服务地址 (localhost + 端口)
  static const String termuxHost = '127.0.0.1';
  static const int termuxPort = 8081;
  
  static const String ubuntuHost = '127.0.0.1';
  static const int ubuntuPort = 8082;

  /// 获取文件列表
  static Future<List<FileEntry>> listFiles(FileSystemType type, String path) async {
    if (type == FileSystemType.android) {
      return _listAndroidFiles(path);
    } else {
      String host = type == FileSystemType.termux ? termuxHost : ubuntuHost;
      int port = type == FileSystemType.termux ? termuxPort : ubuntuPort;
      return _listRemoteFiles(host, port, path);
    }
  }

  /// 获取安卓本地文件列表 (模拟 Shizuku 调用)
  static Future<List<FileEntry>> _listAndroidFiles(String path) async {
    // 实际应调用 Shizuku 服务读取
    // 这里返回模拟数据用于演示
    return [
      FileEntry(name: 'DCIM', isDir: true, path: '$path/DCIM'),
      FileEntry(name: 'Download', isDir: true, path: '$path/Download'),
      FileEntry(name: 'Android', isDir: true, path: '$path/Android'),
      FileEntry(name: 'example.txt', isDir: false, path: '$path/example.txt', size: 1024),
    ];
  }

  /// 获取远程文件列表 (HTTP)
  static Future<List<FileEntry>> _listRemoteFiles(String host, int port, String path) async {
    try {
      final response = await http.get(
        Uri.parse('http://$host:$port/files?path=${Uri.encodeComponent(path)}')
      );
      
      if (response.statusCode == 200) {
        final List<dynamic> jsonList = json.decode(response.body);
        return jsonList.map((e) => FileEntry.fromJson(e)).toList();
      } else {
        print("HTTP 错误: ${response.statusCode}");
      }
    } catch (e) {
      print("连接远程服务失败: $e");
    }
    return [];
  }

  /// 移动/重命名文件
  static Future<bool> moveFile(FileSystemType type, String source, String dest) async {
    if (type == FileSystemType.android) {
      return ShizukuService.copyFile(source, dest); // 简化处理
    } else {
      String host = type == FileSystemType.termux ? termuxHost : (type == FileSystemType.ubuntu ? ubuntuHost : '');
      int port = type == FileSystemType.termux ? termuxPort : (type == FileSystemType.ubuntu ? ubuntuPort : 0);
      
      if (host.isEmpty) return false;

      try {
        final response = await http.post(
          Uri.parse('http://$host:$port/move'),
          headers: {"Content-Type": "application/json"},
          body: json.encode({'source': source, 'dest': dest}),
        );
        return response.statusCode == 200;
      } catch (e) {
        print("移动文件失败: $e");
        return false;
      }
    }
  }
}
