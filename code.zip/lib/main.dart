import 'package:flutter/material.dart';
import 'services/shizuku_service.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // 初始化 Shizuku
  await ShizukuService.init();
  
  runApp(const TriFileManagerApp());
}

class TriFileManagerApp extends StatelessWidget {
  const TriFileManagerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '三栖文件管理器',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
