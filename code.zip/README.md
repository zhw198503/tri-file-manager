# 三栖文件管理器 (Tri-File-Manager)

一个能同时管理 **安卓原生**、**Termux**、**Ubuntu** 三个环境文件的文件管理器。

## 核心功能

- ✅ 统一界面管理三个文件系统
- ✅ 支持文件浏览、移动、复制、删除
- ✅ 基于 Shizuku 实现安卓高权限访问 (无需 Root)
- ✅ Termux/Ubuntu 通过本地 HTTP 服务提供文件访问

## 前置条件

1. **安卓端**:
   - 安装 **Shizuku** (从 [GitHub Releases](https://github.com/RikkaApps/Shizuku/releases) 下载)
   - 通过无线调试激活 Shizuku (无需 Root)

2. **开发环境**:
   - 安装 Flutter SDK
   - 安装 Android Studio (用于编译 APK)

3. **后端环境**:
   - Termux 和 Ubuntu 中安装 Python 3

## 部署步骤

### 1. 启动后端服务

**在 Termux 中运行:**
```bash
# 安装 Python (如果未安装)
pkg install python

# 启动服务
cd /path/to/tri_file_manager/backend
python termux_server.py
```
*服务将监听 `http://127.0.0.1:8081`*

**在 Ubuntu 中运行:**
```bash
# 启动服务
cd /path/to/tri_file_manager/backend
python3 ubuntu_server.py
```
*服务将监听 `http://127.0.0.1:8082`*

### 2. 配置网络 (关键)

确保安卓 App 能访问 Termux 和 Ubuntu 的 `localhost` 端口：
- Termux 需要开启网络权限。
- Ubuntu (如果是 Proot 环境) 需确保与安卓的网络互通。

### 3. 编译安卓 App

```bash
cd /path/to/tri_file_manager

# 获取依赖
flutter pub get

# 编译 APK (Release 模式)
flutter build apk --release

# 或者编译为 Debug 模式用于调试
flutter build apk --debug
```

生成的 APK 位于: `build/app/outputs/flutter-apk/app-release.apk`

### 4. 安装与使用

1. 将生成的 APK 安装到平板。
2. 打开 App，首次运行会请求 Shizuku 权限，请点击**允许**。
3. 确保 Termux 和 Ubuntu 的后端服务正在运行。
4. 在 App 底部导航栏切换不同环境，开始管理文件！

## 项目结构

```
tri_file_manager/
├── lib/
│   ├── main.dart                  # 入口
│   ├── services/
│   │   ├── shizuku_service.dart   # Shizuku 服务封装
│   │   └── file_service.dart      # 文件操作核心逻辑
│   └── screens/
│       └── home_screen.dart       # 主界面
├── backend/
│   ├── termux_server.py           # Termux 后端
│   └── ubuntu_server.py           # Ubuntu 后端
├── pubspec.yaml                   # Flutter 配置
└── README.md                      # 本文件
```

## 注意事项

- **Shizuku 权限**: 首次使用需手动激活，之后开机自启 (部分机型需重新激活)。
- **网络隔离**: 如果 Termux/Ubuntu 与安卓 App 不在同一网络命名空间，可能无法通过 `127.0.0.1` 互通。此时需配置网络共享或使用 `10.0.2.2` 等网桥地址。
- **安全性**: 当前后端服务无认证，仅限本地 `localhost` 使用，**切勿暴露到公网**。

## 下一步优化建议

1. **完善 Shizuku 原生桥接**: 在 `android/` 目录编写 Java 代码，真正调用 Shizuku API 操作文件。
2. **增加文件传输功能**: 实现三端文件的互传 (如：安卓 -> Termux)。
3. **添加文件预览**: 支持图片、文本预览。
4. **后台保活**: 确保后端服务在后台稳定运行。

---
**享受三系统文件互通的快感！**
