#!/usr/bin/env python3
"""
Termux 文件服务后端
监听 8081 端口，提供文件操作 API
"""
from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.parse
import os
import json
import shutil

class FileHandler(BaseHTTPRequestHandler):
    def _send_json(self, data, status=200):
        self.send_response(status)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        
        if parsed.path == '/files':
            params = urllib.parse.parse_qs(parsed.query)
            path = params.get('path', ['/'])[0]
            # 解码路径
            path = urllib.parse.unquote(path)
            
            if path == '/':
                # Termux 中映射安卓存储
                path = os.path.expanduser('~') 
            
            try:
                if not os.path.exists(path):
                    self._send_json({'error': 'Path not found'}, 404)
                    return

                files = []
                for name in os.listdir(path):
                    full_path = os.path.join(path, name)
                    files.append({
                        'name': name,
                        'isDir': os.path.isdir(full_path),
                        'path': full_path,
                        'size': os.path.getsize(full_path) if os.path.isfile(full_path) else 0
                    })
                self._send_json(files)
            except Exception as e:
                self._send_json({'error': str(e)}, 500)
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == '/move':
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length).decode('utf-8')
            data = json.loads(post_data)
            
            source = data.get('source')
            dest = data.get('dest')
            
            try:
                if source and dest:
                    shutil.move(source, dest)
                    self._send_json({'success': True})
                else:
                    self._send_json({'error': 'Missing source or dest'}, 400)
            except Exception as e:
                self._send_json({'error': str(e)}, 500)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        # 简化日志输出
        print(f"[Termux Server] {args[0]}")

if __name__ == '__main__':
    port = 8081
    server = HTTPServer(('127.0.0.1', port), FileHandler)
    print(f"Termux 文件服务运行在 http://127.0.0.1:{port}")
    server.serve_forever()
